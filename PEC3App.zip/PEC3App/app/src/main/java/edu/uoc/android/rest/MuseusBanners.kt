package edu.uoc.android.rest

class MuseusBanners {
    data class Museus(val url: String, val nom: String)

}