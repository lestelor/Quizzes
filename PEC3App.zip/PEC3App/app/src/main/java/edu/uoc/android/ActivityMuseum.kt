package edu.uoc.android


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import edu.uoc.android.rest.*
import edu.uoc.android.rest.models.Museums
import kotlinx.android.synthetic.main.activity_museum.*
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class ActivityMuseum : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    val animals: ArrayList<String> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_museum)

        /*// Retrofit
        val client = OkHttpClient()
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl(APIConstants.API_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val museuService = retrofit.create(MuseumService::class.java)
        val call = museuService.museums("1", "2")

        call.enqueue(object : Callback<Museums> {
            override fun onResponse(call: Call<Museums>, response: Response<Museums>) {
                if (response.code() == 200) {
                    //
                    // showProgres s ( f a l s e ) ;
                    //
                    //
                    val museums = response.body()!!
                    //val aa=museums.elements.component1()
                    // Adapter <<-  /museums // elements
                }
            }

            override fun onFailure(call: Call<Museums>, t: Throwable) {
                // Log.d (TAG, "" xxxxx ")
            }
        })


        // Loads animals into the ArrayList
        addAnimals()

        viewManager = LinearLayoutManager(this)
        viewAdapter = MuseuAdapter(animals, this)

        recyclerView = findViewById<RecyclerView>(R.id.rv_museums).apply {
            // use this setting to improve performance if you know that changes
            // in content do not change the layout size of the RecyclerView
            setHasFixedSize(true)

            // use a linear layout manager
            layoutManager = viewManager

            // specify an viewAdapter (see also next example)
            adapter = viewAdapter

        }*/
    }
    // Adds animals to the empty animals ArrayList
    fun addAnimals() {

        animals.add("dog")
        animals.add("cat")
        animals.add("owl")
        animals.add("cheetah")
        animals.add("raccoon")
    }
}






