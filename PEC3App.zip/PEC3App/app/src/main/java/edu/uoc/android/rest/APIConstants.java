package edu.uoc.android.rest;


public class APIConstants {

    public static final String API_URL="https://do.diba.cat";

}
